const ratings = [
    {
      value: 5,
      label: "Excellent",
    },
    {
      value: 4,
      label: "Good",
    },
    {
      value: 3,
      label: "Average",
    },
    {
      value: 2,
      label: "Poor",
    },
    {
      value: 0,
      label: "Terrible",
    },
  ];
    export default ratings
  